#!/usr/bin/env bash

#
# Program: Update zabbix-agent-dbmon for Oracle <update_zabbix_agent_dbmon.sh>
#
# Author: Mikhail Grigorev <sleuthhound at gmail dot com>
# 
# Current Version: 1.0.0
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#

SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

if [ -f "${SCRIPT_DIR}/settings.conf" ]; then
	. ${SCRIPT_DIR}/settings.conf
else
	echo "Error: Settings file '${SCRIPT_DIR}/settings.conf' not found."
	exit 1
fi

PLATFORM="unknown"
UNAME_INFO=$(uname -s)
case "${UNAME_INFO}" in
	Linux)
		PLATFORM='linux'
		;;
	AIX|Darwin)
		PLATFORM='aix'
		;;
	HP-UX)
		PLATFORM='hp-ux'
		echo "Sorry, while the HP-UX platform is not supported, but we are working on support right now."
		exit 1
		;;
	Solaris|SunOS)
		PLATFORM='sunos'
		echo "Sorry, while the SunOS platform is not supported, but we are working on support right now."
		exit 1
		;;
	*)
		echo "This OS is not supported, please, contact the developer by sleuthhound@programs74.ru"
		exit 1
		;;
esac

echo -n "Checking your privileges... "
CURRENT_USER=$(whoami)
if [[ "${CURRENT_USER}" = "root" ]]; then
	echo "OK"
else
	echo "Error: root access is required"
	exit 1
fi

if [ ! -d "${ZBX_DEFAULT_DIR}" ]; then
	echo "Error: Zabbix default config directory '${ZBX_DEFAULT_DIR}' not found"
	exit 1
fi

if [[ "${PLATFORM}" = "aix" ]]; then
	echo -n "Detect AIX version... "
	AIX_VER=$(oslevel -s | awk -F'-' '{print $1"-"$2"-"$3}')
	echo ${AIX_VER}

	if [ ! -d "${SCRIPT_DIR}/${AIX_VER}" ]; then
		echo "Error: The zabbix-agent for database monitoring was not found for this AIX version."
		exit 1
	fi
fi

if [[ "${PLATFORM}" = "aix" ]]; then
     TOTAL_RUNNING_AGENT=$(ps -ef | grep -E "^.*zabbix_agentd -c.*" | grep -v grep | wc -l | sed 's/^[ \t]*//;s/[ ]*$//')
     TOTAL_RUNNING_DBMON_AGENT=$(ps -ef | grep -E "^.*zabbix_agentd_dbmon -c.*" | grep -v grep | wc -l | sed 's/^[ \t]*//;s/[ ]*$//')
else
     TOTAL_RUNNING_AGENT=$(ps -ef | grep -E "^.*zabbix_agentd -c.*" | grep -v grep | wc -l | sed 's/^[ \t]*//;s/[ \t]*$//')
     TOTAL_RUNNING_DBMON_AGENT=$(ps -ef | grep -E "^.*zabbix_agentd_dbmon -c.*" | grep -v grep | wc -l | sed 's/^[ \t]*//;s/[ \t]*$//')
fi

echo "Found ${TOTAL_RUNNING_AGENT} running zabbix-agent"
echo "Found ${TOTAL_RUNNING_DBMON_AGENT} running zabbix-agent-dbmon"

if [ ${TOTAL_RUNNING_DBMON_AGENT} -ne 0 ]; then
	if [ ${TOTAL_RUNNING_DBMON_AGENT} -gt 1 ]; then
		echo "Found multi zabbix-agent-dbmon configuration."
		ZBX_MULTI_AGENT=1
	else
		ZBX_MULTI_AGENT=0
	fi
else
	echo "Error: Not found running zabbix-agent-dbmon."
	exit 1
fi

_start_stop_zbx_agent() {
	local ZBX_ACTION=$1
	local ZBX_AGENT_PREFIX=$2
	if [[ "${ZBX_ACTION}" = "stop" ]]; then
		local ZBX_AGENT_ACTION=stop
		local ZBX_AGENT_ACTION_DESC="Stoping"
		local ZBX_ACTION_RESULT=0
	else
		local ZBX_AGENT_ACTION=start
		local ZBX_AGENT_ACTION_DESC="Starting"
		local ZBX_ACTION_RESULT=1
	fi
	if [[ "${PLATFORM}" = "aix" ]]; then
		if [ -n "${ZBX_AGENT_PREFIX}" ]; then
			echo -n "${ZBX_AGENT_ACTION_DESC} zabbix-agent-dbmon-${ZBX_AGENT_PREFIX}... "
			${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ZBX_AGENT_PREFIX} ${ZBX_AGENT_ACTION} >/dev/null 2>&1
			echo -n "waiting... "
			sleep 1 >/dev/null 2>&1
			CHECK_RUN=$(ps -ef |grep [z]abbix_agentd_dbmon | grep -e ".*-c.*zabbix_agentd_dbmon_${ZBX_AGENT_PREFIX}.conf" | grep -v grep | wc -l | sed 's/^[ \t]*//;s/[ ]*$//')
		else
			echo -n "${ZBX_AGENT_ACTION_DESC} zabbix-agent-dbmon... "
			${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon ${ZBX_AGENT_ACTION} >/dev/null 2>&1
			echo -n "waiting... "
			sleep 1 >/dev/null 2>&1
			CHECK_RUN=$(ps -ef |grep [z]abbix_agentd_dbmon | grep -e ".*-c.*zabbix_agentd_dbmon.conf" | grep -v grep | wc -l | sed 's/^[ \t]*//;s/[ ]*$//')
		fi
	else
		if [ -n "${ZBX_AGENT_PREFIX}" ]; then
			echo -n "${ZBX_AGENT_ACTION_DESC} zabbix-agent-dbmon@${ZBX_AGENT_PREFIX}... "
			systemctl ${ZBX_AGENT_ACTION} zabbix-agent-dbmon@${ZBX_AGENT_PREFIX} >/dev/null 2>&1
			echo -n "waiting... "
			sleep 1 >/dev/null 2>&1
			CHECK_RUN=$(ps -ef |grep [z]abbix_agentd_dbmon | grep -e ".*-c.*zabbix_agentd_dbmon_${ZBX_AGENT_PREFIX}.conf" | grep -v grep | wc -l)
		else
			echo -n "${ZBX_AGENT_ACTION_DESC} zabbix-agent-dbmon... "
			systemctl ${ZBX_AGENT_ACTION} zabbix-agent-dbmon >/dev/null 2>&1
			echo -n "waiting... "
			sleep 1 >/dev/null 2>&1
			CHECK_RUN=$(ps -ef |grep [z]abbix_agentd_dbmon | grep -e ".*-c.*zabbix_agentd_dbmon.conf" | grep -v grep | wc -l)
		fi
	fi
	if [ ${CHECK_RUN} -eq ${ZBX_ACTION_RESULT} ]; then
		echo "Done (${ZBX_ACTION_RESULT})"
	else
		echo "Error (${ZBX_ACTION_RESULT})"
	fi
}

_update_agent_binary() {
	local ZBX_AGENT_BIN=$1
	if [[ "${PLATFORM}" = "aix" ]]; then
		echo -n "Update agent binary file '${ZBX_AGENT_BIN}'... "
		echo y | cp "${SCRIPT_DIR}/${AIX_VER}/sbin/zabbix_agentd_dbmon" "${ZBX_AGENT_BIN}" >/dev/null 2>&1
		EXIT_CODE=$?
	else
		if [[ "${DB_TYPE}" = "oracle" ]]; then
			echo -n "Update agent binary v${ZBX_VER} for Oracle v${ORA_VER}... "
			echo y | cp "${SCRIPT_DIR}/usr/sbin/zabbix_agentd_dbmon_v${ZBX_VER}_${DB_TYPE}_v${ORA_VER}" "${ZBX_AGENT_BIN}" >/dev/null 2>&1
		elif [[ "${DB_TYPE}" = "mysql" ]]; then
			echo -n "Update agent binary v${ZBX_VER} for MySQL v${MYSQL_VER}... "
			echo y | cp "${SCRIPT_DIR}/usr/sbin/zabbix_agentd_dbmon_v${ZBX_VER}_${DB_TYPE}_v${MYSQL_VER}" "${ZBX_AGENT_BIN}" >/dev/null 2>&1
		else
			echo "Error: Binary for database type '${DB_TYPE}' not found."
			exit 1
		fi
		EXIT_CODE=$?
	fi
	if [ ${EXIT_CODE} -eq 0 ]; then
		echo "Done"
	else
		echo "Error"
	fi
}

_update_agent_sql_bash() {
	echo -n "Update userparameter_dbmon.conf file... "
	echo y | cp "${SCRIPT_DIR}/etc/zabbix/zabbix_agentd_dbmon.d/userparameter_dbmon.conf" "/etc/zabbix/zabbix_agentd_dbmon.d" >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Done"
	else
		echo "Error"
	fi
	echo -n "Update dbmon.sh file... "
	echo y | cp "${SCRIPT_DIR}/etc/zabbix/zabbix_agentd_dbmon.d/dbmon.sh" "/etc/zabbix/zabbix_agentd_dbmon.d" >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Done"
	else
		echo "Error"
	fi
    if [ -f "/etc/zabbix/zabbix_agentd_dbmon_sql.conf" ]; then
        echo -n "Move zabbix_agentd_dbmon_sql.conf to zabbix_agentd_dbmon.sql.conf..."
        mv "/etc/zabbix/zabbix_agentd_dbmon_sql.conf" "/etc/zabbix/zabbix_agentd_dbmon.sql.conf" >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            echo "Done"
        else
            echo "Error"
        fi
    else
    	echo -n "Update zabbix_agentd_dbmon.sql.conf file... "
    	echo y | cp "${SCRIPT_DIR}/etc/zabbix/zabbix_agentd_dbmon.sql.conf" "/etc/zabbix" >/dev/null 2>&1
	    if [ $? -eq 0 ]; then
		    echo "Done"
    	else
	    	echo "Error"
    	fi
    fi
}

_update_startup_script_for_aix() {
        local ZBX_AGENT_PREFIX=$1
        local ORA_TAB_ORA_HOME=$(cat "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ZBX_AGENT_PREFIX}" | grep "export ORACLE_HOME" | awk -F'=' '{print $2}')
        local ORA_INSTANCE_TO_LOWER=${ZBX_AGENT_PREFIX}
        local ORA_INST_NAME=$(cat "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ZBX_AGENT_PREFIX}" | grep "export ORACLE_SID" | awk -F'=' '{print $2}')
        local ZBX_CONFIG_NAME=/etc/zabbix/zabbix_agentd_dbmon_${ZBX_AGENT_PREFIX}.conf
        #echo "Update zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER} startup script..."
        #echo "ZBX_AGENT_PREFIX=$1"
        #echo "ORA_TAB_ORA_HOME=$ORA_TAB_ORA_HOME"
        #echo "ORA_INSTANCE_TO_LOWER=$ORA_INSTANCE_TO_LOWER"
        #echo "ORA_INST_NAME=$ORA_INST_NAME"
        #echo "ZBX_CONFIG_NAME=$ZBX_CONFIG_NAME"
        echo -n "Recreate zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER} startup script... "
(cat <<-EOF
#!/bin/sh

# Zabbix
# Copyright (C) 2001-2019 Zabbix SIA
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# Start/Stop the Zabbix agent daemon.
# Place a startup script in /sbin/init.d, and link to it from /sbin/rc[023].d

SERVICE="Zabbix agent DBMON (${ORA_INSTANCE_TO_LOWER})"
DAEMON=/sbin/zabbix_agentd_dbmon
CONFFILE=${ZBX_CONFIG_NAME}
PIDFILE=/var/run/zabbix/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.pid

export NLS_LANG=AMERICAN_AMERICA.CL8MSWIN1251
export ORACLE_HOME=${ORA_TAB_ORA_HOME}
export ORACLE_SID=${ORA_INST_NAME}
export PATH=\$ORACLE_HOME/bin:/sbin:/bin:/usr/sbin:/usr/bin
export LIBPATH=\$ORACLE_HOME/lib:/opt/freeware/lib64:\$LIBPATH

case \$1 in
        'start')
                if [ -x \${DAEMON} ]; then
                        \$DAEMON -c \$CONFFILE
                        # Error checking here would be good...
                        echo "\${SERVICE} started."
                else
                        echo "Can not find file \${DAEMON}."
                        echo "\${SERVICE} NOT started."
                fi
        ;;

        'stop')
                if [ -s \${PIDFILE} ]; then
                        if kill \$(cat \${PIDFILE}) >/dev/null 2>&1; then
                                echo "\${SERVICE} terminated."
                                rm -f \${PIDFILE}
                        fi
                fi
        ;;

        'restart')
                \$0 stop
                sleep 5
                \$0 start
        ;;

        *)
                echo "Usage: \$0 start|stop|restart"
        ;;
esac
EOF
) > "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}"

        if [ -f "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" ]; then
                chmod a+x "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" >/dev/null 2>&1
                echo "Done"
        else
                echo "Error"
                exit 1
        fi
}

_update_startup_script_for_aix_single() {
        local ORA_TAB_ORA_HOME=$(cat "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon" | grep "export ORACLE_HOME" | awk -F'=' '{print $2}')
        local ORA_INST_NAME=$(cat "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon" | grep "export ORACLE_SID" | awk -F'=' '{print $2}')
        local ZBX_CONFIG_NAME=/etc/zabbix/zabbix_agentd_dbmon.conf
        echo -n "Recreate zabbix-agent-dbmon startup script... "
(cat <<-EOF
#!/bin/sh

# Zabbix
# Copyright (C) 2001-2019 Zabbix SIA
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# Start/Stop the Zabbix agent daemon.
# Place a startup script in /sbin/init.d, and link to it from /sbin/rc[023].d

SERVICE="Zabbix agent DBMON"
DAEMON=/sbin/zabbix_agentd_dbmon
CONFFILE=${ZBX_CONFIG_NAME}
PIDFILE=/var/run/zabbix/zabbix_agentd_dbmon.pid

export NLS_LANG=AMERICAN_AMERICA.CL8MSWIN1251
export ORACLE_HOME=${ORA_TAB_ORA_HOME}
export ORACLE_SID=${ORA_INST_NAME}
export PATH=\$ORACLE_HOME/bin:/sbin:/bin:/usr/sbin:/usr/bin
export LIBPATH=\$ORACLE_HOME/lib:/opt/freeware/lib64:\$LIBPATH

case \$1 in
        'start')
                if [ -x \${DAEMON} ]; then
                        \$DAEMON -c \$CONFFILE
                        # Error checking here would be good...
                        echo "\${SERVICE} started."
                else
                        echo "Can not find file \${DAEMON}."
                        echo "\${SERVICE} NOT started."
                fi
        ;;

        'stop')
                if [ -s \${PIDFILE} ]; then
                        if kill \$(cat \${PIDFILE}) >/dev/null 2>&1; then
                                echo "\${SERVICE} terminated."
                                rm -f \${PIDFILE}
                        fi
                fi
        ;;

        'restart')
                \$0 stop
                sleep 5
                \$0 start
        ;;

        *)
                echo "Usage: \$0 start|stop|restart"
        ;;
esac
EOF
) > "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon"

        if [ -f "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon" ]; then
                chmod a+x "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon" >/dev/null 2>&1
                echo "Done"
        else
                echo "Error"
                exit 1
        fi
}

OLD_IFS=$IFS
IFS=$'\n'

if [[ "${PLATFORM}" = "aix" ]]; then
	PS_FIND=($(ps -eo user,args | grep zabbix_agentd_dbmon | grep conf | sed 's/^[ \t]*//;s/[ ]*$//' 2>/dev/null))
else
	PS_FIND=($(ps -eo user,cmd | grep zabbix_agentd_dbmon | grep conf | sed 's/^[ \t]*//;s/[ \t]*$//' 2>/dev/null))
fi

if [ $? -eq 0 ]; then
	PS_FIND_NUM=${#PS_FIND[*]}
	if [ ${PS_FIND_NUM} -ne 0 ]; then
		for ((J=0; J<${#PS_FIND[@]}; J++)); do
			if [ -n "${PS_FIND[$J]}" ]; then
				ZBX_AGENT_BIN=$(echo "${PS_FIND[$J]}" | awk -F' ' '{print $2}')
				ZBX_AGENT_CONF=$(echo "${PS_FIND[$J]}" | awk -F' ' '{print $4}')
				ZBX_AGENT_CONF_NAME=$(basename ${ZBX_AGENT_CONF})
				ZBX_AGENT_CONF_NAME_WITHOUT_EXT=${ZBX_AGENT_CONF_NAME%.*}
				#echo ${ZBX_AGENT_BIN} ${ZBX_AGENT_CONF_NAME} ${ZBX_AGENT_CONF_NAME_WITHOUT_EXT}
				if [[ ${ZBX_AGENT_CONF_NAME_WITHOUT_EXT} = "zabbix_agentd_dbmon" ]]; then
					ZBX_AGENT_PREFIX=""
					_start_stop_zbx_agent "stop" ""
				else
					ZBX_AGENT_PREFIX=$(echo "${ZBX_AGENT_CONF_NAME_WITHOUT_EXT}" | cut -d'_' -f4- 2>/dev/null)
					_start_stop_zbx_agent "stop" "${ZBX_AGENT_PREFIX}"
				fi
				if [ ${ZBX_MULTI_AGENT} -eq 0 ]; then
					_update_agent_binary "${ZBX_AGENT_BIN}"
					_update_agent_sql_bash
				fi
				if [[ "${PLATFORM}" = "aix" ]]; then
					if [ -z "${ZBX_AGENT_PREFIX}" ]; then
						_update_startup_script_for_aix_single
					else
						_update_startup_script_for_aix "${ZBX_AGENT_PREFIX}"
					fi
				fi
				echo -n "Update agent config file '${ZBX_AGENT_CONF}'... "
				if [ -f "${ZBX_AGENT_CONF}" ]; then
					ZBX_TIMEOUT_CNT=0
					ZBX_TIMEOUT_CNT=$(grep -E -c "^Timeout=*." "${ZBX_AGENT_CONF}" 2>/dev/null)
					if [ ${ZBX_TIMEOUT_CNT} -eq 0 ]; then
						if [[ "${PLATFORM}" = "aix" ]]; then
							sed -e "s@# Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_AGENT_CONF}" > "${ZBX_AGENT_CONF}.tmp"
							mv "${ZBX_AGENT_CONF}.tmp" "${ZBX_AGENT_CONF}"
						else
							sed -i -e "s@# Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_AGENT_CONF}"
						fi
					else
						if [[ "${PLATFORM}" = "aix" ]]; then
							sed -e "s@Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_AGENT_CONF}" > "${ZBX_AGENT_CONF}.tmp"
							mv "${ZBX_AGENT_CONF}.tmp" "${ZBX_AGENT_CONF}"
						else
							sed -i -e "s@Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_AGENT_CONF}"
						fi
					fi
					ZBX_DB_TIMEOUT_CNT=0
					ZBX_DB_TIMEOUT_CNT=$(grep -E -c "^DBTimeout=*." "${ZBX_AGENT_CONF}" 2>/dev/null)
					if [ ${ZBX_DB_TIMEOUT_CNT} -eq 0 ]; then
						ZBX_DB_TIMEOUT_COMMENT_CNT=0
						ZBX_DB_TIMEOUT_COMMENT_CNT=$(grep -E -c "^# DBTimeout=*." "${ZBX_AGENT_CONF}" 2>/dev/null)
						if [ ${ZBX_DB_TIMEOUT_COMMENT_CNT} -eq 0 ]; then
							(cat <<-EOF

## Option: DBTimeout
#	Spend no more than DBTimeout seconds on processing database query in threaded.
#
# Mandatory: no
# Range: 1-180
# Default:
# DBTimeout=60
DBTimeout=${ZBX_DB_TIMEOUT}
							EOF
							) >> "${ZBX_AGENT_CONF}"
						else
							if [[ "${PLATFORM}" = "aix" ]]; then
								sed -e "s@# DBTimeout=.*@DBTimeout=${ZBX_DB_TIMEOUT}@g" "${ZBX_AGENT_CONF}" > "${ZBX_AGENT_CONF}.tmp"
								mv "${ZBX_AGENT_CONF}.tmp" "${ZBX_AGENT_CONF}"
							else
								sed -i -e "s@# DBTimeout=.*@DBTimeout=${ZBX_DB_TIMEOUT}@g" "${ZBX_AGENT_CONF}"
							fi
						fi
					else
						if [[ "${PLATFORM}" = "aix" ]]; then
							sed -e "s@DBTimeout=.*@DBTimeout=${ZBX_DB_TIMEOUT}@g" "${ZBX_AGENT_CONF}" > "${ZBX_AGENT_CONF}.tmp"
							mv "${ZBX_AGENT_CONF}.tmp" "${ZBX_AGENT_CONF}"
						else
							sed -i -e "s@DBTimeout=.*@DBTimeout=${ZBX_DB_TIMEOUT}@g" "${ZBX_AGENT_CONF}"
						fi
					fi
					ZBX_ORA_USE_LOCAL_ENV_CNT=0
					ZBX_ORA_USE_LOCAL_ENV_CNT=$(grep -E -c "^OracleUseLocalEnv=*." "${ZBX_AGENT_CONF}" 2>/dev/null)
					if [ ${ZBX_ORA_USE_LOCAL_ENV_CNT} -eq 0 ]; then
						ZBX_ORA_USE_LOCAL_ENV_COMMENT_CNT=0
						ZBX_ORA_USE_LOCAL_ENV_COMMENT_CNT=$(grep -E -c "^# OracleUseLocalEnv=*." "${ZBX_AGENT_CONF}" 2>/dev/null)
						if [ ${ZBX_ORA_USE_LOCAL_ENV_COMMENT_CNT} -eq 0 ]; then
							(cat <<-EOF

### Option: OracleUseLocalEnv
#	Ignore connection string, reciving from zabbix-server and use ORACLE_SID or TWO_TASK enviroment variable for connection Oracle instance.
#	To connect to an Oracle instance using ORACLE_SID or TWO_TASK variables, the zabbix user (see User setting from Agents) must be added to the dba group.
#
# Mandatory: no
# Default:
# OracleUseLocalEnv=0
OracleUseLocalEnv=${ORA_USE_LOCAL_ENV}
							EOF
							) >> "${ZBX_AGENT_CONF}"
						else
							if [[ "${PLATFORM}" = "aix" ]]; then
								sed -e "s@# OracleUseLocalEnv=.*@OracleUseLocalEnv=${ORA_USE_LOCAL_ENV}@g" "${ZBX_AGENT_CONF}" > "${ZBX_AGENT_CONF}.tmp"
								mv "${ZBX_AGENT_CONF}.tmp" "${ZBX_AGENT_CONF}"
							else
								sed -i -e "s@# OracleUseLocalEnv=.*@OracleUseLocalEnv=${ORA_USE_LOCAL_ENV}@g" "${ZBX_AGENT_CONF}"
							fi
						fi
					else
						if [[ "${PLATFORM}" = "aix" ]]; then
							sed -e "s@OracleUseLocalEnv=.*@OracleUseLocalEnv=${ORA_USE_LOCAL_ENV}@g" "${ZBX_AGENT_CONF}" > "${ZBX_AGENT_CONF}.tmp"
							mv "${ZBX_AGENT_CONF}.tmp" "${ZBX_AGENT_CONF}"
						else
							sed -i -e "s@OracleUseLocalEnv=.*@OracleUseLocalEnv=${ORA_USE_LOCAL_ENV}@g" "${ZBX_AGENT_CONF}"
						fi
					fi
					echo "Done"
				else
					echo "Error"
				fi
				if [ ${ZBX_MULTI_AGENT} -eq 0 ]; then
					_start_stop_zbx_agent "start" "${ZBX_AGENT_PREFIX}"
				fi
			fi
		done
		if [ ${ZBX_MULTI_AGENT} -eq 1 ]; then
			_update_agent_binary "${ZBX_AGENT_BIN}"
			_update_agent_sql_bash
			for ((I=0; I<${#PS_FIND[@]}; I++)); do
				if [ -n "${PS_FIND[$I]}" ]; then
					ZBX_AGENT_BIN=$(echo "${PS_FIND[$I]}" | awk -F' ' '{print $2}')
					ZBX_AGENT_CONF=$(echo "${PS_FIND[$I]}" | awk -F' ' '{print $4}')
					ZBX_AGENT_CONF_NAME=$(basename ${ZBX_AGENT_CONF})
					ZBX_AGENT_CONF_NAME_WITHOUT_EXT=${ZBX_AGENT_CONF_NAME%.*}
					#echo ${ZBX_AGENT_BIN} ${ZBX_AGENT_CONF_NAME} ${ZBX_AGENT_CONF_NAME_WITHOUT_EXT}
					if [[ ${ZBX_AGENT_CONF_NAME_WITHOUT_EXT} = "zabbix_agentd_dbmon" ]]; then
						ZBX_AGENT_PREFIX=""
					else
						ZBX_AGENT_PREFIX=$(echo "${ZBX_AGENT_CONF_NAME_WITHOUT_EXT}" | cut -d'_' -f4- 2>/dev/null)
					fi
					_start_stop_zbx_agent "start" "${ZBX_AGENT_PREFIX}"
				fi
			done
		fi
	else
		echo "Error: Not found running zabbix-agent-dbmon."
	fi
else
	echo "Error: Not found running zabbix-agent-dbmon."
fi
IFS=${OLD_IFS}
