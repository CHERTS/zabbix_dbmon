#!/usr/bin/env bash

#
# Program: Basic install zabbix-agent-dbmon for Oracle <install_zabbix_agent_dbmon.sh>
#
# Author: Mikhail Grigorev <sleuthhound at gmail dot com>
# 
# Current Version: 1.0.0
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#

SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

if [ -f "${SCRIPT_DIR}/settings.conf" ]; then
	. ${SCRIPT_DIR}/settings.conf
else
	echo "Error: Settings file '${SCRIPT_DIR}/settings.conf' not found."
	exit 1
fi

echo -n "Checking your privileges... "
CURRENT_USER=$(whoami)
if [[ "${CURRENT_USER}" = "root" ]]; then
	echo "OK"
else
	echo "Error: root access is required"
	exit 1
fi

PLATFORM="unknown"
UNAME_INFO=$(uname -s)
case "${UNAME_INFO}" in
	Linux)
		PLATFORM='linux'
		# Local settings
		export LANG=en_US.UTF-8
		export LANGUAGE=en_US.UTF-8
		export LC_COLLATE=C
		export LC_CTYPE=en_US.UTF-8
		;;
	AIX|Darwin)
		PLATFORM='aix'
		export LANG=C
		export NLS_LANG=AMERICAN_AMERICA.CL8MSWIN1251
		export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"
		;;
	HP-UX)
		PLATFORM='hp-ux'
		echo "Sorry, while the HP-UX platform is not supported, but we are working on support right now."
		exit 1
		;;
	Solaris|SunOS)
		PLATFORM='sunos'
		echo "Sorry, while the SunOS platform is not supported, but we are working on support right now."
		exit 1
		;;
	*)
		echo "This OS is not supported, please, contact the developer by sleuthhound@programs74.ru"
		exit 1
		;;
esac

_add_user_to_group() {
	local USER_G=${1}
	local GROUP_G=${2}
	local ZBX_DBA_CHECK=""
	ret=false
	if [[ "${PLATFORM}" = "linux" ]]; then
		getent group ${GROUP_G} >/dev/null 2>&1 && ret=true
	elif [[ "${PLATFORM}" = "aix" ]]; then
		lsgroup ${GROUP_G} >/dev/null 2>&1 && ret=true
	fi
	if $ret; then
		ZBX_DBA_CHECK=$(id -nG ${USER_G} | grep ${GROUP_G})
		if [ -z "${ZBX_DBA_CHECK}" ]; then
			echo -n "Adding user \"${USER_G}\" to group \"${GROUP_G}\"... "
			if [[ "${PLATFORM}" = "linux" ]]; then
				usermod -a -G ${GROUP_G} ${USER_G} >/dev/null 2>&1
			elif [[ "${PLATFORM}" = "aix" ]]; then
				usermod -G `id -nG ${USER_G} | tr " " ","`,${GROUP_G} ${USER_G} >/dev/null 2>&1
			fi
			ZBX_DBA_CHECK=$(id -nG ${USER_G} | grep ${GROUP_G})
			if [ -n "${ZBX_DBA_CHECK}" ]; then
				echo "OK"
			else
				echo "ERR"
			fi
		else
			echo "User \"${USER_G}\" already member of the group \"${GROUP_G}\"."
		fi
	else
		echo "WARNING: Group '${GROUP_G}' not found."
	fi

}

_pre_configure_zabbix_agentd() {
	echo -n "Check zabbix home directory... "
	if [[ "${PLATFORM}" = "linux" ]]; then
		ZBX_HOME_DIR_CHECK=$(getent passwd ${ZBX_DEFAULT_USER} | cut -d':' -f 6)
	elif [[ "${PLATFORM}" = "aix" ]]; then
		ZBX_HOME_DIR_CHECK=$(lsuser -a home ${ZBX_DEFAULT_USER} | cut -d'=' -f 2)
	else
		ZBX_HOME_DIR_CHECK=${ZBX_DEFAULT_HOME_DIR}
	fi
	if [ -d "${ZBX_HOME_DIR_CHECK}" ]; then
		ZBX_DEFAULT_HOME_DIR="$(echo ${ZBX_HOME_DIR_CHECK} | sed 's/\/$//')"
		echo "OK"
	else
		echo "NotSet"
	fi
	if [ ! -d "${ZBX_DEFAULT_HOME_DIR}" ]; then
		echo -n "Create zabbix home directory... "
		mkdir ${ZBX_DEFAULT_HOME_DIR} >/dev/null 2>&1
		if [ -d "${ZBX_DEFAULT_HOME_DIR}" ]; then
			echo "OK"
		else
			echo "ERR, code $?"
			exit 1
		fi
	fi
}

_create_zabbix_user() {
	echo -n "Checking group '${ZBX_DEFAULT_GROUP}'... "
	lsgroup -a id ${ZBX_DEFAULT_GROUP} >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "Not found"
		echo -n "Create group '${ZBX_DEFAULT_GROUP}'... "
		mkgroup ${ZBX_DEFAULT_GROUP} >/dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo "OK"
		else
			echo "ERR, code $?"
			exit 1
		fi
	fi
	echo -n "Checking user '${ZBX_DEFAULT_USER}'... "
	lsuser ${ZBX_DEFAULT_USER} >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "Not found"
		echo -n "Create user '${ZBX_DEFAULT_USER}'... "
		mkuser pgrp=${ZBX_DEFAULT_GROUP} groups=${ZBX_DEFAULT_GROUP} ${ZBX_DEFAULT_USER} >/dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo "OK"
		else
			echo "ERR, code $?"
			exit 1
		fi
	fi
	echo -n "Change settings for user '${ZBX_DEFAULT_USER}'... "
	usermod -d ${ZBX_DEFAULT_HOME_DIR} ${ZBX_DEFAULT_USER} >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "ERR, code $?"
		exit 1
	fi
	echo -n "Create working directory... "
	mkdir ${ZBX_DEFAULT_DIR}/zabbix_agentd.d >/dev/null 2>&1
	mkdir -p ${ZBX_DEFAULT_HOME_DIR} >/dev/null 2>&1
	mkdir -p ${ZBX_DEFAULT_PID_DIR} >/dev/null 2>&1
	mkdir -p ${ZBX_DEFAULT_LOG_DIR} >/dev/null 2>&1
	chown -R ${ZBX_DEFAULT_USER}:${ZBX_DEFAULT_GROUP} ${ZBX_DEFAULT_HOME_DIR} >/dev/null 2>&1
	chown -R ${ZBX_DEFAULT_USER}:${ZBX_DEFAULT_GROUP} ${ZBX_DEFAULT_PID_DIR} >/dev/null 2>&1
	chown -R ${ZBX_DEFAULT_USER}:${ZBX_DEFAULT_GROUP} ${ZBX_DEFAULT_LOG_DIR} >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "ERR, code $?"
		exit 1
	fi
}

if [[ "${PLATFORM}" = "aix" ]]; then
	echo -n "Detect AIX version... "
	AIX_VER=$(oslevel -s | awk -F'-' '{print $1"-"$2"-"$3}')
	echo ${AIX_VER}

	if [ ! -d "${SCRIPT_DIR}/${AIX_VER}" ]; then
		echo "Error: The zabbix-agent for database monitoring was not found for this AIX version."
		exit 1
	fi
fi

if [ ! -d "${ZBX_DEFAULT_DIR}" ]; then
	echo -n "Create directory '${ZBX_DEFAULT_DIR}'... "
	mkdir "${ZBX_DEFAULT_DIR}" >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "ERR, code $?"
		exit 1
	fi
fi

echo -n "Searching user '${ZBX_DEFAULT_USER}'... "
if [[ "${PLATFORM}" = "aix" ]]; then
	lsuser ${ZBX_DEFAULT_USER} >/dev/null 2>&1
else
	getent passwd ${ZBX_DEFAULT_USER} >/dev/null 2>&1
fi

if [ $? -eq 0 ]; then
	echo "Found"
else
	echo "Not found"
	_create_zabbix_user
fi

_pre_configure_zabbix_agentd
_add_user_to_group "${ZBX_DEFAULT_USER}" "${ORACLE_DEFAULT_SYSDBA_GROUP}"
_add_user_to_group "${ZBX_DEFAULT_USER}" "${ORACLE_DEFAULT_OINSTALL_GROUP}"

echo -n "Searching Oracle ASM instance... "
OLD_IFS=$IFS
IFS=$'\n'
if [[ "${PLATFORM}" = "aix" ]]; then
	PS_FIND=($(ps -eo user,args | grep [a]sm_smon_ | sed 's/^[ \t]*//;s/[ ]*$//' 2>/dev/null))
else
	PS_FIND=($(ps -eo user,cmd | grep [a]sm_smon_ | sed 's/^[ \t]*//;s/[ \t]*$//' 2>/dev/null))
fi
if [ $? -eq 0 ]; then
	PS_FIND_NUM=${#PS_FIND[*]}
	if [ ${PS_FIND_NUM} -eq 0 ]; then
		echo "Not found"
	else
		echo "Found"
		_add_user_to_group "${ZBX_DEFAULT_USER}" "${ORACLE_DEFAULT_ASMDBA_GROUP}"
		_add_user_to_group "${ZBX_DEFAULT_USER}" "${ORACLE_DEFAULT_ASMADMIN_GROUP}"
	fi
fi
IFS=$OLD_IFS

if [[ "${PLATFORM}" = "aix" ]]; then
	echo -n "Copy zabbix-agent for dbmon binary... "
	cp ${SCRIPT_DIR}/${AIX_VER}/sbin/zabbix_agentd_dbmon /sbin >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "ERR, code $?"
	fi
fi

echo -n "Copy default sql config..."
cp ${SCRIPT_DIR}/etc/zabbix/zabbix_agentd_dbmon.sql.conf ${ZBX_DEFAULT_DIR} >/dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "OK"
else
	echo "ERR, code $?"
fi

if [ ! -d "${ZBX_DEFAULT_DIR}/zabbix_agentd_dbmon.d" ]; then
	echo -n "Create config sub-directory... "
	mkdir -p ${ZBX_DEFAULT_DIR}/zabbix_agentd_dbmon.d >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "ERR, code $?"
	fi
fi


if [ -d "${ZBX_DEFAULT_DIR}/zabbix_agentd_dbmon.d" ]; then
	echo -n "Copy userparameter_dbmon.conf... "
	cp ${SCRIPT_DIR}/etc/zabbix/zabbix_agentd_dbmon.d/userparameter_dbmon.conf ${ZBX_DEFAULT_DIR}/zabbix_agentd_dbmon.d >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "ERR, code $?"
	fi
	echo -n "Copy dbmon.sh... "
	cp  ${SCRIPT_DIR}/etc/zabbix/zabbix_agentd_dbmon.d/dbmon.sh ${ZBX_DEFAULT_DIR}/zabbix_agentd_dbmon.d >/dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "OK"
	else
		echo "ERR, code $?"
	fi
fi
