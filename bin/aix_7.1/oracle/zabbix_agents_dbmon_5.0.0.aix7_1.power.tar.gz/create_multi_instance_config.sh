#!/bin/bash

ORACLE_DEFAULT_ORATAB_PATH="/etc/oratab"
ZBX_DEFAULT_SYSCONFIG="/etc/sysconfig"
ZBX_DEFAULT_PID_DIR="/var/run/zabbix"
ZBX_DEFAULT_LOG_DIR="/var/log/zabbix"
ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR=/etc/rc.d/init.d
ZBX_SERVER=10.113.25.62
ZBX_SERVER_PORT=11311
ZBX_TIMEOUT=120
ZBX_LISTEN_PORT=11312
ORA_USERNAME="zabbixmon"
ORA_USERPASSWORD="EaF7LaNgah3t"

SERVERNAME=$(hostname)

PLATFORM="unknown"
UNAME_INFO=$(uname -s)
case "${UNAME_INFO}" in
	Linux)
		PLATFORM='linux'
		# Local settings
		export LANG=en_US.UTF-8
		export LANGUAGE=en_US.UTF-8
		export LC_COLLATE=C
		export LC_CTYPE=en_US.UTF-8
		;;
	AIX|Darwin)
		PLATFORM='aix'
		export LANG=C
		export NLS_LANG=AMERICAN_AMERICA.CL8MSWIN1251
		export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"
		;;
	HP-UX)
		PLATFORM='hp-ux'
		echo "Sorry, while the HP-UX platform is not supported, but we are working on support right now."
		exit 1
		;;
	Solaris|SunOS)
		PLATFORM='sunos'
		echo "Sorry, while the SunOS platform is not supported, but we are working on support right now."
		exit 1
		;;
	*)
		echo "This OS is not supported, please, contact the developer by sleuthhound@programs74.ru"
		exit 1
		;;
esac

echo -n "Check ${ORACLE_DEFAULT_ORATAB_PATH} file... "
if [ -f "${ORACLE_DEFAULT_ORATAB_PATH}" ]; then
	echo "Found"
else
	echo "Error"
	exit 1
fi

function create_link() {
	local SRC_FILE=$1
	local DST_LINK=$2
	if [ -f "${SRC_FILE}" ]; then
		if [ -L "${DST_LINK}" ]; then
			if [ -e "${DST_LINK}" ]; then
				echo "Good"
			else
				unlink "${DST_LINK}"
				ln -s "${SRC_FILE}" "${DST_LINK}"
				echo "Recreate"
			fi
		elif [ -e "${DST_LINK}" ] ; then
			echo "Not_a_link"
		else
			ln -s "${SRC_FILE}" "${DST_LINK}"
			if [ -L "${DST_LINK}" ]; then
				if [ -e "${DST_LINK}" ]; then
					echo "Create_Good"
				else
					echo "Create_NotGood"
				fi
			else
				echo "NotCreate"
			fi
		fi
	fi
}

OLD_IFS=$IFS
IFS=$'\n'
if [[ "${PLATFORM}" = "aix" ]]; then
	PS_FIND=($(ps -eo user,args | grep [o]ra_smon | sed 's/^[ \t]*//;s/[ ]*$//' 2>/dev/null))
else
	PS_FIND=($(ps -eo user,cmd | grep [o]ra_smon | sed 's/^[ \t]*//;s/[ \t]*$//' 2>/dev/null))
fi
if [ $? -eq 0 ]; then
	PS_FIND_NUM=${#PS_FIND[*]}
	#declare -p PS_FIND
	for ((i=0; i<${#PS_FIND[@]}; i++)); do
		#echo "ARR: "${PS_FIND[$i]}
		if [ -n "${PS_FIND[$i]}" ]; then
			ORA_USER=$(echo "${PS_FIND[$i]}" | awk -F' ' '{print $1}')
			ORA_INST_NAME=$(echo "${PS_FIND[$i]}" | awk -F' ' '{print $2}' | cut -d "_" -f 3)
			#echo "USER:$ORA_USER|INST:$ORA_INST_NAME"
			echo "Found instance \"${ORA_INST_NAME}\", owner \"${ORA_USER}\"."
			ORA_TAB_INSTANCE=""
			ORA_TAB_ORA_HOME=""
			echo -n "Check ORACLE_HOME for instance ${ORA_INST_NAME} in ${ORACLE_DEFAULT_ORATAB_PATH} file... "
			if [[ "${PLATFORM}" = "aix" ]]; then
				ORA_TAB_INSTANCE=$(cat "${ORACLE_DEFAULT_ORATAB_PATH}" | egrep -v '^#|^$' | awk -F':' '{print $1}' | grep -E "^${ORA_INST_NAME}$")
				if [ -n "${ORA_TAB_INSTANCE}" ]; then
					ORA_TAB_ORA_HOME=$(cat "${ORACLE_DEFAULT_ORATAB_PATH}" | egrep -v '^#|^$' | grep -E "^${ORA_INST_NAME}:" | awk -F':' '{print $2}')
				fi
			else
				ORA_TAB_INSTANCE=$(cat "${ORACLE_DEFAULT_ORATAB_PATH}" | egrep -Ev '^\s*(;|#|$)' | awk -F':' '{print $1}' | grep -E "^${ORA_INST_NAME}$")
				if [ -n "${ORA_TAB_INSTANCE}" ]; then
					ORA_TAB_ORA_HOME=$(cat "${ORACLE_DEFAULT_ORATAB_PATH}" | egrep -Ev '^\s*(;|#|$)' | grep -E "^${ORA_INST_NAME}:" | awk -F':' '{print $2}')
				fi
			fi
			if [ -n "${ORA_TAB_INSTANCE}" -a -n "${ORA_TAB_ORA_HOME}" ]; then
				if [[ "${ORA_INST_NAME}" = "${ORA_TAB_INSTANCE}" ]]; then
					echo "Found"
					echo -n "Checking ORACLE_HOME directory '${ORA_TAB_ORA_HOME}'... "
					if [ -d "${ORA_TAB_ORA_HOME}" ]; then
						echo "Done"
						ORA_INSTANCE_TO_LOWER=$(echo "${ORA_INST_NAME}" | tr '[:upper:]' '[:lower:]')
						ZBX_CONFIG_NAME=/etc/zabbix/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.conf
						if [[ "${PLATFORM}" = "linux" ]]; then
							ZBX_SYSCONFIG_INSTANCE_FILE="${ZBX_DEFAULT_SYSCONFIG}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}"
							echo -n "Create zabbix-agent environment file '${ZBX_SYSCONFIG_INSTANCE_FILE}'... "
							echo "ORACLE_HOME=${ORA_TAB_ORA_HOME}" > ${ZBX_SYSCONFIG_INSTANCE_FILE}
							echo "ORACLE_SID=${ORA_INST_NAME}" >> ${ZBX_SYSCONFIG_INSTANCE_FILE}
							echo "PATH=${ORA_TAB_ORA_HOME}/bin:/sbin:/bin:/usr/sbin:/usr/bin" >> ${ZBX_SYSCONFIG_INSTANCE_FILE}
							echo "LD_LIBRARY_PATH=${ORA_TAB_ORA_HOME}/lib" >> ${ZBX_SYSCONFIG_INSTANCE_FILE}
							if [ -f "${ZBX_SYSCONFIG_INSTANCE_FILE}" ]; then
								echo "Done"
							else
								echo "Error"
								exit 1
							fi
						elif [[ "${PLATFORM}" = "aix" ]]; then
							echo -n "Create zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER} startup script... "
(cat <<-EOF
#!/bin/sh
##########################################################
###### Zabbix agent daemon init script
##########################################################
test -x /sbin/zabbix_agentd_dbmon || exit 5
case "\$1" in
start)
        echo "Starting zabbix_agent_dbmon (${ORA_INSTANCE_TO_LOWER})..."
        export NLS_LANG=AMERICAN_AMERICA.CL8MSWIN1251
        export ORACLE_HOME=${ORA_TAB_ORA_HOME}
        export ORACLE_SID=${ORA_INST_NAME}
        export PATH=\$ORACLE_HOME/bin:/sbin:/bin:/usr/sbin:/usr/bin
        export LIBPATH=\$ORACLE_HOME/lib:\$LIBPATH
        /sbin/zabbix_agentd_dbmon -c ${ZBX_CONFIG_NAME}
        ;;
stop)
        echo "Stopping zabbix_agent_dbmon (${ORA_INSTANCE_TO_LOWER})..."
        kill -TERM \$(cat /var/run/zabbix/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.pid)
        ;;
restart)
        echo "Restarting zabbix_agent_dbmon (${ORA_INSTANCE_TO_LOWER})..."
        \$0 stop
        sleep 3
        \$0 start
        ;;
*)
        echo "Usage: \$0 {start|stop|restart}"
        exit 1
        ;;
esac
EOF
) > "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}"
							if [ -f "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" ]; then
								chmod a+x "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" >/dev/null 2>&1
								ln -s "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" "/etc/rc.d/rc2.d/S95zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" >/dev/null 2>&1
								ln -s "${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" "/etc/rc.d/rc2.d/K95zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" >/dev/null 2>&1
								echo "Done"
							else
								echo "Error"
								exit 1
							fi
						fi
						if [[ "${PLATFORM}" = "linux" ]]; then
							if [ ! -f "${ORA_TAB_ORA_HOME}/lib/libnnz18.so" ]; then
								echo -n "Create libnnz18.so library symlink... "
								create_link "${ORA_TAB_ORA_HOME}/lib/libnnz11.so" "${ORA_TAB_ORA_HOME}/lib/libnnz18.so"
								create_link "${ORA_TAB_ORA_HOME}/lib/libnnz12.so" "${ORA_TAB_ORA_HOME}/lib/libnnz18.so"
							fi
							if [ ! -f "${ORA_TAB_ORA_HOME}/lib/libclntsh.so.18.1" ]; then
								echo -n "Create libclntsh.so.18.1 library symlink... "
								create_link "${ORA_TAB_ORA_HOME}/lib/libclntsh.so" "${ORA_TAB_ORA_HOME}/lib/libclntsh.so.18.1"
							fi
						fi
						echo -n "Create zabbix-agent config for '${ORA_INSTANCE_TO_LOWER}'... "
						cp "etc/zabbix/zabbix_agentd_dbmon.conf" "${ZBX_CONFIG_NAME}" 2>/dev/null
						if [ -f "${ZBX_CONFIG_NAME}" ]; then
							if [[ "${PLATFORM}" = "aix" ]]; then
								LAST_LISTEN_PORT=$(netstat -an -f inet | grep LISTEN | grep 113 | awk '{print $4}' | awk -F'.' '{print $2}' | sort -n | tail -1)
							else
								LAST_LISTEN_PORT=$(netstat -ltnp -4|grep [z]abbix_agentd | awk '{print $4}' | awk -F':' '{print $2}' | sort -n | tail -1)
							fi
							if [ -n "${LAST_LISTEN_PORT}" ]; then
								NEXT_LISTEN_PORT=$(( ${LAST_LISTEN_PORT} + 1 ))
							else
								NEXT_LISTEN_PORT=$(( ${ZBX_LISTEN_PORT} + 1 ))
							fi
							if [[ "${PLATFORM}" = "aix" ]]; then
								sed -e "s@# ListenPort=.*@ListenPort=${NEXT_LISTEN_PORT}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed "s@# Hostname=@Hostname=${SERVERNAME}.${ORA_INSTANCE_TO_LOWER}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@PidFile=.*@PidFile=${ZBX_DEFAULT_PID_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.pid@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@LogFile=.*@LogFile=${ZBX_DEFAULT_LOG_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.log@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@Server=.*@Server=127.0.0.1,${ZBX_SERVER}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@ServerActive=.*@ServerActive=${ZBX_SERVER}:${ZBX_SERVER_PORT}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@# HostMetadata=.*@HostMetadata=OracleAIX@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@# OracleUser=.*@OracleUser=${ORA_USERNAME}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@# OraclePassword=.*@OraclePassword=${ORA_USERPASSWORD}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
								sed -e "s@# Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
								mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
							else
								sed -i -e "s@# ListenPort=.*@ListenPort=${NEXT_LISTEN_PORT}@g" "${ZBX_CONFIG_NAME}"
								sed -i "s@# Hostname=@Hostname=${SERVERNAME}.${ORA_INSTANCE_TO_LOWER}@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@PidFile=.*@PidFile=${ZBX_DEFAULT_PID_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.pid@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@LogFile=.*@LogFile=${ZBX_DEFAULT_LOG_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.log@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@Server=.*@Server=127.0.0.1,${ZBX_SERVER}@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@ServerActive=.*@ServerActive=${ZBX_SERVER}:${ZBX_SERVER_PORT}@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@# HostMetadata=.*@HostMetadata=OracleLinux@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@# OracleUser=.*@OracleUser=${ORA_USERNAME}@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@# OraclePassword=.*@OraclePassword=${ORA_USERPASSWORD}@g" "${ZBX_CONFIG_NAME}"
								sed -i -e "s@# Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_CONFIG_NAME}"
							fi
							echo "Done"
							echo "Agent settings: Server: ${ZBX_SERVER}:${ZBX_SERVER_PORT}, ListenPort: ${NEXT_LISTEN_PORT}"
						else
							echo "Error"
						fi
						if [[ "${PLATFORM}" = "linux" ]]; then
							echo -n "Create logrotate for '${ORA_INSTANCE_TO_LOWER}'..."
(cat <<-EOF
${ZBX_DEFAULT_LOG_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.log {
        weekly
        rotate 12
        compress
        delaycompress
        missingok
        notifempty
        create 0664 zabbix zabbix
}
EOF
) > /etc/logrotate.d/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}
							if [ -f "/etc/logrotate.d/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER}" ]; then
								echo "Done"
							else
								echo "Error"
							fi
							echo -n "Starting zabbix-agent-dbmon@${ORA_INSTANCE_TO_LOWER}... "
							systemctl restart zabbix-agent-dbmon@${ORA_INSTANCE_TO_LOWER} >/dev/null 2>&1
							CHECK_RUN=$(ps -ef |grep [z]abbix_agentd_dbmon | grep -e ".*-c.*zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.conf" | grep -v grep | wc -l)
							if [ ${CHECK_RUN} -ne 0 ]; then
								echo "Done"
							else
								echo "Error"
							fi
						elif [[ "${PLATFORM}" = "aix" ]]; then
							echo -n "Starting zabbix-agent-dbmon@${ORA_INSTANCE_TO_LOWER}... "
							${ZBX_DEFAULT_AIX_STARTUP_SCRIPT_DIR}/zabbix-agent-dbmon-${ORA_INSTANCE_TO_LOWER} start >/dev/null 2>&1
							CHECK_RUN=$(ps -ef |grep [z]abbix_agentd_dbmon | grep -e ".*-c.*zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.conf" | grep -v grep | wc -l)
							if [ ${CHECK_RUN} -ne 0 ]; then
								echo "Done"
							else
								echo "Error"
							fi
						fi
						echo "Waiting 1 second... "
						sleep 1
					else
						echo "Error"
					fi
				else
					echo "InstanceNotFound"
					ORA_TAB_ORA_HOME=""
				fi
			else
				echo "NotFound"
				ORA_TAB_ORA_HOME=""
			fi
		fi
	done
	if [ ${PS_FIND_NUM} -eq 0 ]; then
		echo "WARNING. No oracle instances of the running were found."
	fi
fi
IFS=$OLD_IFS

echo "Please, creating user 'zabbixmon' on all Oracle instance manualy! Use password: ${ORA_USERPASSWORD}"
