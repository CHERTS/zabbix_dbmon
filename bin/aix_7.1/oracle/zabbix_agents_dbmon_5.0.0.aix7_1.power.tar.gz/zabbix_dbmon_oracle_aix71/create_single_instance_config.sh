#!/bin/bash

ZBX_DEFAULT_PID_DIR="/var/run/zabbix"
ZBX_DEFAULT_LOG_DIR="/var/log/zabbix"
ZBX_CONFIG_NAME=/etc/zabbix/zabbix_agentd_dbmon.conf
ZBX_SERVER=10.113.25.62
ZBX_SERVER_PORT=11311
ZBX_TIMEOUT=120
ORA_USERNAME="zabbixmon"
ORA_USERPASSWORD="EaF7LaNgah3t"
ORA_INSTANCE_TO_LOWER="orcl"

PLATFORM="unknown"
UNAME_INFO=$(uname -s)
case "${UNAME_INFO}" in
	Linux)
		PLATFORM='linux'
		# Local settings
		export LANG=en_US.UTF-8
		export LANGUAGE=en_US.UTF-8
		export LC_COLLATE=C
		export LC_CTYPE=en_US.UTF-8
		;;
	AIX|Darwin)
		PLATFORM='aix'
		export LANG=C
		export NLS_LANG=AMERICAN_AMERICA.CL8MSWIN1251
		export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"
		;;
	HP-UX)
		PLATFORM='hp-ux'
		echo "Sorry, while the HP-UX platform is not supported, but we are working on support right now."
		exit 1
		;;
	Solaris|SunOS)
		PLATFORM='sunos'
		echo "Sorry, while the SunOS platform is not supported, but we are working on support right now."
		exit 1
		;;
	*)
		echo "This OS is not supported, please, contact the developer by sleuthhound@programs74.ru"
		exit 1
		;;
esac

echo -n "Create zabbix-agent config for '${ORA_INSTANCE_TO_LOWER}'... "
cp "etc/zabbix/zabbix_agentd_dbmon.conf" "${ZBX_CONFIG_NAME}" 2>/dev/null
if [ -f "${ZBX_CONFIG_NAME}" ]; then
	if [[ "${PLATFORM}" = "aix" ]]; then
		sed -e '/^# ListenPort=.*/a \\ListenPort=11311' "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed "s@# Hostname=@Hostname=${SERVERNAME}.${ORA_INSTANCE_TO_LOWER}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@PidFile=.*@PidFile=${ZBX_DEFAULT_PID_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.pid@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@LogFile=.*@LogFile=${ZBX_DEFAULT_LOG_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.log@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@Server=.*@Server=127.0.0.1,${ZBX_SERVER}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@ServerActive=.*@ServerActive=${ZBX_SERVER}:${ZBX_SERVER_PORT}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@# HostMetadata=.*@HostMetadata=OracleLinux@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@# OracleUser=.*@OracleUser=${ORA_USERNAME}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@# OraclePassword=.*@OraclePassword=${ORA_USERPASSWORD}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
		sed -e "s@# Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_CONFIG_NAME}" > "${ZBX_CONFIG_NAME}.tmp"
		mv "${ZBX_CONFIG_NAME}.tmp" "${ZBX_CONFIG_NAME}"
	else
		sed -i -e '/^# ListenPort=.*/a \\ListenPort=11311' "${ZBX_CONFIG_NAME}"
		sed -i "s@# Hostname=@Hostname=${SERVERNAME}.${ORA_INSTANCE_TO_LOWER}@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@PidFile=.*@PidFile=${ZBX_DEFAULT_PID_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.pid@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@LogFile=.*@LogFile=${ZBX_DEFAULT_LOG_DIR}/zabbix_agentd_dbmon_${ORA_INSTANCE_TO_LOWER}.log@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@Server=.*@Server=127.0.0.1,${ZBX_SERVER}@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@ServerActive=.*@ServerActive=${ZBX_SERVER}:${ZBX_SERVER_PORT}@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@# HostMetadata=.*@HostMetadata=OracleLinux@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@# OracleUser=.*@OracleUser=${ORA_USERNAME}@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@# OraclePassword=.*@OraclePassword=${ORA_USERPASSWORD}@g" "${ZBX_CONFIG_NAME}"
		sed -i -e "s@# Timeout=.*@Timeout=${ZBX_TIMEOUT}@g" "${ZBX_CONFIG_NAME}"
	fi
	echo "Done"
else
	echo "Error"
fi

echo "Please, creating user 'zabbixmon' in Oracle in manualy! Use password: XXXXXXX"
echo "Please, run zabbix-agent-dbmon manualy."
