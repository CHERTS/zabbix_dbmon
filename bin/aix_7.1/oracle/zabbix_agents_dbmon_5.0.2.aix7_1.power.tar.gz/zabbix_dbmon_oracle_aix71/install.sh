#!/bin/bash

SCRIPT_DIR=$(dirname $0)

if [ -f "${SCRIPT_DIR}/settings.conf" ]; then
	. ${SCRIPT_DIR}/settings.conf
else
	echo "Error: Settings file '${SCRIPT_DIR}/settings.conf' not found."
	exit 1
fi

PLATFORM="unknown"
UNAME_INFO=$(uname -s)
case "${UNAME_INFO}" in
	Linux)
		PLATFORM='linux'
		# Local settings
		export LANG=en_US.UTF-8
		export LANGUAGE=en_US.UTF-8
		export LC_COLLATE=C
		export LC_CTYPE=en_US.UTF-8
		;;
	AIX|Darwin)
		PLATFORM='aix'
		export LANG=C
		export NLS_LANG=AMERICAN_AMERICA.CL8MSWIN1251
		export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"
		;;
	HP-UX)
		PLATFORM='hp-ux'
		echo "Sorry, while the HP-UX platform is not supported, but we are working on support right now."
		exit 1
		;;
	Solaris|SunOS)
		PLATFORM='sunos'
		echo "Sorry, while the SunOS platform is not supported, but we are working on support right now."
		exit 1
		;;
	*)
		echo "This OS is not supported, please, contact the developer by sleuthhound@programs74.ru"
		exit 1
		;;
esac

if [[ "${PLATFORM}" = "aix" ]]; then
	echo "Step 1: Copy agent binary..."
	cp sbin/zabbix_agentd_dbmon /sbin
fi

echo "Step 2: Copy default sql config..."
cp etc/zabbix/zabbix_agentd_dbmon_sql.conf /etc/zabbix

if [ ! -d "/etc/zabbix/zabbix_agentd_dbmon.d" ]; then
	echo "Step 3: Create config sub-directory..."
	mkdir -p /etc/zabbix/zabbix_agentd_dbmon.d 2>/dev/null
fi


if [ -d "/etc/zabbix/zabbix_agentd_dbmon.d" ]; then
	echo "Step 4: Copy userparameter_dbmon.conf..."
	cp etc/zabbix/zabbix_agentd_dbmon.d/userparameter_dbmon.conf /etc/zabbix/zabbix_agentd_dbmon.d 2>/dev/null
	echo "Step 5: Copy dbmon.sh..."
	cp etc/zabbix/zabbix_agentd_dbmon.d/dbmon.sh /etc/zabbix/zabbix_agentd_dbmon.d 2>/dev/null
fi
